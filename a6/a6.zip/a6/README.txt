NAME or NAMES: 
- Eric Hsieh: ehsieh25
- Yajas Malhotra: yajasm

If working in a group, briefly state the work done by each person.
- We both work on our individual parts, and then we compare our answers.
- We take time to analyze each implementation and see who has the best.
- For the final work, Yajas contributed most to (c)
- I contribute most to (d) and modified (c)
- We both had the same idea for the creative component.

COMMENTS:
- initialize() in a6.html initializes the world geometry of four spheres. This function is called in main().
- Only sphere0, the smallest sphere, correspond to the isLight boolean.
- raycast will call raycast2(), and raycast2() will call (the creative component I made) raycast3(). GLSL doesn't allow for recursive funcitons.

- For the CREATIVE COMPONENT, I created the third reflection of the sphere called raycast3().
- localShade doesn't seems to take in value I, so I modified it.

Please add any comments that you wish to pass on to the graders or instructor.
